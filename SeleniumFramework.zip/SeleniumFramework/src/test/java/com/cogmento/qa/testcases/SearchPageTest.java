package com.cogmento.qa.testcases;

import java.time.Duration;

import org.cogmento.qa.baseclass.BaseClass;
import org.testng.annotations.Test;

public class SearchPageTest extends BaseClass{

	

}
