package org.cogmento.qa.pages;

import org.cogmento.qa.baseclass.BaseClass;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CommonFeaturesPage extends BaseClass {

	
	public CommonFeaturesPage() 
    {
	PageFactory.initElements(driver,this);	
    }
	
	@FindBy(xpath="//input[@placeholder='Search']") 
	WebElement search; 
	
	@FindBy(xpath= "//i[@class ='settings icon']")
	WebElement setting;
	
	@FindBy(xpath="//i[@class ='shop icon']")
	WebElement productIcon;
	
	
	
//	@FindBy(xpath= "//div[contains(@class,'floating item drop')]")
//	WebElement setting;
	
	public SearchPage searchbar(String searchvalue) {
		search.sendKeys(searchvalue);
		search.sendKeys(Keys.ENTER);
		return new SearchPage();
	}
	
	public void clickSetting() {
		setting.click();
	}
	
	public void clickProduct() {
		productIcon.click();
	}
}




