package org.cogmento.qa.baseclass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public static WebDriver driver;
	public static Properties prop;
	public static DesiredCapabilities caps = new DesiredCapabilities();

	public BaseClass() {
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(
					"/home/tanmoymondal/eclipse-workspace/CogmentoProject/src/main/java"
							+ "/org/cogmento/qa/config/config.properties");

			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization() {

		String browserName = prop.getProperty("browser");
		if (browserName.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			options.addArguments("--test-type");
			options.addArguments("--disable-popup-blocking");
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-gpu");
			options.addArguments("--disable-crash-reporter");
			options.addArguments("--disable-extensions");
			options.addArguments("--disable-in-process-stack-traces");
			options.addArguments("--disable-logging");
			options.addArguments("--disable-dev-shm-usage");
			options.addArguments("--log-level=3");
			options.addArguments("--output=/dev/null");

			System.setProperty("webdriver.chrome.silentOutput", "true");
			caps.setCapability(ChromeOptions.CAPABILITY, options);
			options.addArguments("--no-sandbox");
			// WebDriver driver= WebDriverManager.chromedriver().create();
			if (driver != null) {
				driver.quit();
			}
			driver = new ChromeDriver(options);

			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

			driver.get(prop.getProperty("url"));

			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		}

	}
}
