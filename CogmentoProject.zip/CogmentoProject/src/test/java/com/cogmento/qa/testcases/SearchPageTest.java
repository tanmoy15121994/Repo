package com.cogmento.qa.testcases;

import org.cogmento.qa.baseclass.BaseClass;

public class SearchPageTest extends BaseClass{

	

}
