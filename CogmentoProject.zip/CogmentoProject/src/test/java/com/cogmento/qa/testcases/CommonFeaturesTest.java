package com.cogmento.qa.testcases;

import java.time.Duration;

import org.cogmento.qa.baseclass.BaseClass;
import org.cogmento.qa.pages.CommonFeaturesPage;
import org.cogmento.qa.pages.HomePage;
import org.cogmento.qa.pages.LoginPage;
import org.cogmento.qa.pages.SearchPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CommonFeaturesTest extends BaseClass{
	
	LoginPage loginpage;
	HomePage homepage;
	CommonFeaturesPage commonfeaturespage;
	
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginpage = new LoginPage();	
		homepage = new HomePage();
		commonfeaturespage = new CommonFeaturesPage();
		homepage =  loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
	}

	@Test(priority=1)
    public SearchPage validateSearch() throws InterruptedException {
    driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(3000));
    commonfeaturespage.searchbar(prop.getProperty("search"));
    Thread.sleep(3000);
    
    return new SearchPage();
    }
	  
    @Test(priority=2)
    public void validateSettingButton() {
    commonfeaturespage.clickSetting();
	
    }
	  
	@Test(priority=3)
    public void validateProductIcon() throws InterruptedException {
    commonfeaturespage.clickSetting();
    Thread.sleep(3000);
    commonfeaturespage.clickProduct();
    Thread.sleep(3000);
 
	}
	  
    @AfterMethod
	public void teardowm() {
	driver.quit();
	}
	  
	  
	  
}



