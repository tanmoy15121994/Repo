package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Eventhelper;

public class EndShowPage {

private WebDriver driver;

public String expectedTitle;
public String actualTitle;

	public EndShowPage(WebDriver driver) {
		this.driver = driver;
	}
	
	By Endshow = By.xpath("//span[normalize-space()='END SHOW']");
	By ManageRecording = By.xpath("//span[normalize-space()='Manage Recording']");
	
	public void clickEndShow() {
		Eventhelper.explicitwaitclickable(driver, Endshow);
		driver.findElement(Endshow).click();
	}
	
	public void clickMangeRecording() {
		Eventhelper.explicitwaitclickable(driver, ManageRecording);
		driver.findElement(ManageRecording).click();
	}
    
	public void verifyEndShow() {
		expectedTitle = "GAVEL - TestGavel";
		actualTitle = driver.getTitle();
	}
}
