package pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.Eventhelper;

public class ProfilePage {

	private WebDriver driver;
	
	public String Expected;
	public String Actual;

	By userIcon = By.xpath("//img[contains(@alt,'user')]");
	By myProfile = By.xpath("//span[normalize-space()='My Profile']");
	By editProfile = By.xpath("//button[@class='ant-btn ant-btn-primary transparentBtn']");
	By email = By.xpath("//input[@id='basic_EmailAddress']");
	By firstName = By.xpath("//input[@id='basic_firstName']");
	By lastName = By.xpath("//input[@id='basic_lastName']");
	By userName = By.xpath("//input[@id='basic_username']");
	By updateProfile = By.xpath("//button[@type='submit']");

	public ProfilePage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickUserIcon() {
		Eventhelper.explicitwaitclickable(driver, userIcon);

		try {
			driver.findElement(userIcon).click();
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
		}
	}

	public void selectMyProfile() {
		Eventhelper.explicitwaitclickable(driver, myProfile);
		driver.findElement(myProfile).click();
	}

	public void clickEditProfile() {

		ArrayList<String> add = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(add.get(1));

		Eventhelper.explicitwaitclickable(driver, editProfile);
		driver.findElement(editProfile).click();
	}

	public void enterEmail() throws InterruptedException {

		WebElement emailfield = driver.findElement(email);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].value='ggavel123@yopmail.com';", emailfield);
		Thread.sleep(1000);
	}

	public void enterFirstName() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver, firstName);

		WebElement firstnamefield = driver.findElement(firstName);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].value='Test';", firstnamefield);
		Thread.sleep(1000);
	}

	public void enterLastName() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver, lastName);

		WebElement lastNameField = driver.findElement(lastName);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].value='Gavel';", lastNameField);
		Thread.sleep(1000);
	}

	public void enterUserName() throws InterruptedException {

		Eventhelper.explicitwaitclickable(driver, userName);

		WebElement userNameField = driver.findElement(userName);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].value='TestGavel';", userNameField);
		Thread.sleep(1000);
	}

	public void clickUpdateProfile() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver, updateProfile);
		driver.findElement(updateProfile).click();
		Thread.sleep(2000);
	}
	
	public void verifyProfileSuccessfullyUpdated() {
	 Expected ="https://stage.gavel.live/profile";
	 Actual = driver.getCurrentUrl();
	}
}
