package pages;

import java.time.Duration;

import org.junit.rules.Timeout;
import org.openqa.selenium.*;
import utility.Eventhelper;

public class LoginPage {

	private WebDriver driver;

	public String expectedTitle;
	public String actualTitle;

	// BY locators:

	By loginbtn = By.xpath("//span[text()='Login']");
	By loginWithEmail = By.xpath("//button[text()='Continue with Email']");
	By email = By.xpath("//input[@type='text']");
	By con = By.xpath("//button[@type='submit']");
	By password = By.xpath("//input[@type='password']");
	By onContinue = By.xpath("//button[@type='submit']");

	// constructor of the page

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickLoginButton() {
		driver.findElement(loginbtn).click();
	}

	public void loginWithEmail() {
		Eventhelper.explicitwaitclickable(driver, loginWithEmail);
		driver.findElement(loginWithEmail).click();
	}

	public void enterEmailAddress() throws InterruptedException {
		Thread.sleep(1000);
		Eventhelper.explicitwaitclickable(driver, email);
		driver.findElement(email).sendKeys("ggavel123@yopmail.com");
	}

	public void clickcontinue() {
		Eventhelper.explicitwaitclickable(driver, con);
		driver.findElement(con).click();
	}

	public void enterPassword() {
		Eventhelper.explicitwaitclickable(driver, password);
		driver.findElement(password).sendKeys("ggavel@123");
	}

	public void verifyEmail() {
		driver.findElement(onContinue).click();
	}

	public void verifySuccessfullLogin() {
		expectedTitle = "GAVEL - TestGavel";
		actualTitle = driver.getTitle();
	}

	public void doLogin() throws InterruptedException {
		clickLoginButton();
		loginWithEmail();
		enterEmailAddress();
		clickcontinue();
		enterPassword();
		verifyEmail();
	}
}
