package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utility.Eventhelper;

public class AddItemPage {

	private WebDriver driver;

	boolean eleDisplayed;

	By addItem = By.xpath("//button[@type='button']//parent::span[text()='Add item']");
	By addAvailableItem = By.xpath("//input[@id='amount']");
	By price = By.xpath("//input[@id='start_price']");
	By itemName = By.xpath("//input[@id='title']");
	By sell = By.xpath("//button[@type='submit']");

	By umlimited = By.xpath("//span[text()='CHECK IF UNLIMITED ITEMS ARE AVAILABLE']");
	By freeItem = By.xpath("//span[text()='CHECK IF THE ITEM IS FREE OF CHARGE']");

	public AddItemPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickAddItem() {
		Eventhelper.explicitwaitclickable(driver, addItem);
		driver.findElement(addItem).click();
	}

	public void enterAvailableItems() {
		Eventhelper.explicitwaitclickable(driver, addItem);
		driver.findElement(addAvailableItem).sendKeys("20");
	}

	public void enterPrice() {
		Eventhelper.explicitwaitclickable(driver, addItem);
		driver.findElement(price).sendKeys("100");
	}

	public void enterItemName() {
		Eventhelper.explicitwaitclickable(driver, addItem);
		driver.findElement(itemName).sendKeys("Chocolates");
	}

	public void clickSubmit() {
		Eventhelper.explicitwaitclickable(driver, addItem);
		driver.findElement(sell).click();
	}

	public void verifyAddedItem() throws InterruptedException {
		Thread.sleep(1000);
		eleDisplayed = driver.findElement(By.xpath("//div[@class ='shopCard']")).isDisplayed();
	}

	public void checkUnlimitedItems() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(umlimited).click();
	}

	public void checkFreeItem() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(freeItem).click();
	}
}
