package steps;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.EndShowPage;
import utility.Driverhelper;

public class EndShowSteps {
	WebDriver driver;

	EndShowPage endshow = new EndShowPage(Driverhelper.getDriver());

	@When("User click on Endshow button.")
	public void user_click_on_endshow_button() {
		endshow.clickEndShow();
	}

	@When("User get a popup and click Manage Recording.")
	public void user_get_a_popup_and_click_manage_recording() {
		endshow.clickMangeRecording();
	}

	@Then("User successfully logout and redirect to profile page.")
	public void user_successfully_logout_and_redirect_to_profile_page() {
		endshow.verifyEndShow();
		assertEquals(endshow.actualTitle, endshow.expectedTitle);
	}
}
