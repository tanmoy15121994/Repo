package steps;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.LoginPage;
import utility.Driverhelper;

public class HomePageSteps {

	WebDriver driver;

	LoginPage loginpage = new LoginPage(Driverhelper.getDriver());
	HomePage homepage = new HomePage(Driverhelper.getDriver());

	@When("User login to application")
	public void User_login_to_application() throws InterruptedException {
		loginpage.doLogin();
	}

	@When("User click on live Event.")
	public void user_click_on_live_Event() throws InterruptedException {
		homepage.clickLiveEvent();
	}

	@Then("User redirect to live event show page.")
	public void user_redirect_to_live_Event_Show_page() {
		homepage.verifyUseronEventPage();
		assertEquals(homepage.actualTitle, homepage.expectedTitle);
	}

	@When("User click on Continue Stream.")
	public void user_click_on_continue_stream() throws InterruptedException {
		Thread.sleep(2000);
		homepage.ContinueStream();
	}

	@When("User click on Start Streaming.")
	public void user_click_on_start_streaming() throws InterruptedException {
		homepage.StartStream();
	}

	@Then("User should able to host the event successfully.")
	public void user_should_able_to_host_the_event_successfully() throws InterruptedException {
		homepage.VerifyStartEvent();
		assertTrue(homepage.value.equals("true"));
	}

	@When("User click on mute button.")
	public void user_click_on_mute_button() throws InterruptedException {
		homepage.hostMuted();
	}

	@Then("User audio should get off.")
	public void user_audio_should_get_off() {
		homepage.verifyAudioMuted();
		assertTrue(homepage.muted.isDisplayed());
	}

	@When("User again click on mute button.")
	public void user_again_click_on_mute_button() throws InterruptedException {
		homepage.hostUnMuted();
	}

	@Then("User audio should get on.")
	public void user_audio_should_get_on() {
		homepage.verifyAudioUnmuted();
		assertTrue(homepage.unmuted.isDisplayed());
		// Assert.assertTrue(homepage.unmuted.isDisplayed());
	}

	@When("User click on Camera button.")
	public void user_click_on_camera_button() throws InterruptedException {
		homepage.hostCameraOff();
	}

	@Then("User camera should get off.")
	public void user_camera_should_get_off() {
		homepage.verifyCameraOff();
		assertTrue(homepage.cameraOff.isDisplayed());
	}

	@When("User again click on Camera button.")
	public void user_again_click_on_camera_button() throws InterruptedException {
		Thread.sleep(1000);
		homepage.hostCameraOn();
	}

	@Then("User Camera should get on.")
	public void user_camera_should_get_on() {
		homepage.VerifyCameraOn();
		assertTrue(homepage.cameraOn.isDisplayed());
	}

	@When("User click on share icon.")
	public void user_click_on_share_icon() throws InterruptedException {
		homepage.clickShareEvent();
	}

	@Then("User should able to copied the link to the clipboard.")
	public void user_should_able_to_copied_the_link_to_the_clipboard() {
		homepage.verifyShareEvent();
		assertTrue(homepage.sharevalue.equals("true"));
	}

	@When("User click on Guest host list option.")
	public void user_click_on_guest_host_list_option() throws InterruptedException {
		homepage.addCoHost();
	}

	@When("User enter the Guesthostemail id.")
	public void user_enter_the_Guesthostemail_id() {
		homepage.enterCoHostEmail();
	}

	@When("User click on send invitation button.")
	public void user_click_on_send_invitation_button() throws InterruptedException {
		homepage.sendInvitationToCoHost();
	}

	@Then("The host user should get a popup Invitation to join as cohost.")
	public void the_host_user_should_get_a_popup_invitation_to_join_as_cohost() {

	}
}